from pathlib import Path

LAMBDA_OUTBOX_DYNAMODB_STREAMS_ZIP_PATH = Path(__file__).parent / "lambda_outbox_dynamodb_streams.zip"

__all__ = [
    "LAMBDA_OUTBOX_DYNAMODB_STREAMS_ZIP_PATH",
]
