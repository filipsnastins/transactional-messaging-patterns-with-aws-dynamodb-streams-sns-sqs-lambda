from pathlib import Path

from lambda_outbox_dynamodb_streams.outbox import create_dynamodb_streams_outbox

LAMBDA_OUTBOX_DYNAMODB_STREAMS_ZIP_PATH = Path(__file__).parent / "lambda_outbox_dynamodb_streams.zip"

__all__ = [
    "LAMBDA_OUTBOX_DYNAMODB_STREAMS_ZIP_PATH",
    "create_dynamodb_streams_outbox",
]
