from lambda_outbox_dynamodb_streams.outbox.outbox import create_dynamodb_streams_outbox

__all__ = [
    "create_dynamodb_streams_outbox",
]
