#!/usr/bin/env python
import tomodachi.cli

if __name__ == "__main__":
    tomodachi.cli.cli_entrypoint()
