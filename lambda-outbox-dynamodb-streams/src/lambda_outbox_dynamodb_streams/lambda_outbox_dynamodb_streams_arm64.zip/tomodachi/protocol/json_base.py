from tomodachi.envelope.json_base import PROTOCOL_VERSION, JsonBase  # noqa

__all__ = [
    "PROTOCOL_VERSION",
    "JsonBase",
]
