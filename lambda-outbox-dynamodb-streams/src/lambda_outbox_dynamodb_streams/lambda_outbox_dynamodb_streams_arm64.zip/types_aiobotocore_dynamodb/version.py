"""
Source of truth for version.
"""
__version__ = "2.6.0"
